package com.hefshine.newtestng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class demo {
	
	@Test
	 void a() throws InterruptedException
	 {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jijau\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://www.saucedemo.com");
		 driver.manage().window().maximize();
		 Thread.sleep(1000);
		 driver.findElement(By.id("user-name")).sendKeys("standard_user");
		 driver.findElement(By.id("password")).sendKeys("secret_sauce");
		 driver.findElement(By.id("login-button")).click();
		 Thread.sleep(2000);
		 WebElement dropdown = driver.findElement(By.className("product_sort_container"));
		 Select select1 = new Select(dropdown);
		 select1.selectByValue("lohi");
		 driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();
		 driver.findElement(By.className("shopping_cart_link")).click();
		 driver.findElement(By.id("checkout")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("first-name")).sendKeys("Samadhan");
		 driver.findElement(By.id("last-name")).sendKeys("Pimple");
		 driver.findElement(By.id("postal-code")).sendKeys("431213");
		 driver.findElement(By.id("continue")).click();
		 driver.findElement(By.id("finish")).click();
		 Thread.sleep(2000);
		 
		 String alerttext = driver.switchTo().activeElement().getText();
		 System.out.println(alerttext);
		 
		 
		 
		 
		
		 
		
	 }
	

}
